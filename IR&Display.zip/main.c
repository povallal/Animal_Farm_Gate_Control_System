#ifndef F_CPU

# define F_CPU 8000000UL 

#endif



#include<avr/io.h>        
#include <stdlib.h>
#include<util/delay.h>    
#include <avr/interrupt.h>
#include "lcd.h"


#include <avr/interrupt.h>


#define LCD_DATA PORTD         // port D is selected as LCD data port

#define ctrl PORTB             //  portB is selected as LCD command port

#define en PB5                 // enable signal is connected to port B pin 5

#define rw PB4                 // read/write signal is connected to port B pin 4

#define rs PB3                 // register select signal is connected to port B pin 3





int count=0;

int digit1s ;
int digit10s ;
int digit100s ;

int main(void)

{

	DDRD=0xFF;              // set LCD data port as output

	DDRB=0B00111000;              // set LCD signals (RS, RW, E) as out put
	

	
	DDRC = ~((1<<DDC2)|(1<<DDC3));
	
	PINC = ~((1<<PC2) | (1<<PC3));
	
	
	 // resistor
	DDRB  &=0B11111110;
	
	init_LCD();             // initialize LCD
	
	LCD_cmd(0x0F);          // display on, cursor blinking

	LCD_Write_String("Animal counting");
	_delay_ms(10);
	
	LCD_cmd(0x01); // clear display
	
	while ((PINB & 0B00000001)==0)

	{
		if (PINC & (1<<PC2))  //Checks if the IR1 is detected
		{
		
			count++;
			LCD_cmd(0x01); // clear display
			
			_delay_ms(10);
			LCD_Write_String("Count::");
			
			LCD_Write_int("d",count);
			
			 _delay_ms(10);
			
			
			
		}
		 else if(PINC& (1<<PC3))    //Checks if the IR2 is detected
		{
			
			count--;
			
	    	LCD_cmd(0x01); // clear display
			_delay_ms(10);         // delay of 10 Milli seconds
			
			LCD_Write_String("Count::");
			
			LCD_Write_int("d",count);
			_delay_ms(10);
			
			
		} 
		
	}


}

void LCD_Write_int(int *b)
{
	
	
	
	digit1s =count%10;
	digit10s= (count%100)/10;
	digit100s=(count%1000)/100;
	
	LCD_write(0x30+digit100s);
	LCD_write(0x30+digit10s);
	LCD_write(0x30+digit1s);
	
	
}
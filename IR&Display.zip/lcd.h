#ifndef F_CPU

# define F_CPU 8000000UL // clock speed is 8MHz

#endif





#define LCD_DATA PORTD         // port Dis selected as LCD data port

#define ctrl PORTB         //  port B is selected as LCD command port

#define en PB5                 // enable signal is connected to port B pin 5

#define rw PB4                 // read/write signal is connected to port B pin 4

#define rs PB3                 // register select signal is connected to port B pin 3







void LCD_cmd(unsigned char cmd)

{

	LCD_DATA = cmd;      // data lines are set to send command*

	PORTB  &= 0B11110111; // RS sets 0

	PORTB &= 0B11101111;// RW sets 0

	PORTB  |= 0B00100000;   // make enable from high to low

	_delay_ms(10);

	PORTB  &= 0B11011111;

	

	return;

}





void LCD_write(unsigned char data)

{

	LCD_DATA= data;       // data lines are set to send command

	PORTB |= ~(0B11110111);    // RS sets 1

	PORTB  &= 0B11101111;   // RW sets 0

	PORTB |= 0B00100000;    // make enable from high to low

	_delay_ms(10);

	PORTB &= 0B11011111;

	

	return ;

}

void init_LCD(void)

{

	LCD_cmd(0x38);           // initialization in 8bit mode of 16X2 LCD

	_delay_ms(1);

	LCD_cmd(0x01);          // make clear LCD

	_delay_ms(1);

	LCD_cmd(0x02);          // return home

	_delay_ms(1);

	LCD_cmd(0x06);          // make increment in cursor

	_delay_ms(1);

	LCD_cmd(0x80);          

	_delay_ms(1);

	

	return;

}


void LCD_Write_String(char *a)
{
	int i;
	for(i=0;a[i]!='\0';i++)
	{
		char big = a[i];
		LCD_write(big);
	}
	 }
  
	 



#include <avr/io.h>
#include <stdio.h>
#include "I2C_Master_H_file.h"

#define Device_Write_address	0xD0			
#define Device_Read_address		0xD1			
#define hour_12_AM				0x40
#define hour_12_PM				0x60
#define hour_24					0x00

void RTC_Clock_Write(char _hour, char _minute, char _second, char AMPM)
{
	_hour |= AMPM;
	I2C_Start(Device_Write_address);			
	I2C_Write(0);								
	I2C_Write(_second);							
	I2C_Write(_minute);							
	I2C_Write(_hour);							
	I2C_Stop();									
}


int main(void)
{
	I2C_Init();
	RTC_Clock_Write(0x11, 0x59, 0x00, hour_12_PM);// Write Hour Minute Second Format 
	
	while(1);
}
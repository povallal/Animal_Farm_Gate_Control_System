

#include "LCD16x2_4bit.h"

void lcdcommand(unsigned char cmnd)
{
	LCD_DPRT = (LCD_DPRT & 0x0f)|(cmnd & 0xf0);		
	LCD_DPRT &= ~ (1<<LCD_RS);						
	LCD_DPRT |= (1<<LCD_EN);						
	_delay_us(1);									
	LCD_DPRT &= ~(1<<LCD_EN);						
	_delay_us(100);									
	
	LCD_DPRT = (LCD_DPRT & 0x0f)|(cmnd << 4);		
	LCD_DPRT |= (1<<LCD_EN);						
	_delay_us(1);									
	LCD_DPRT &= ~(1<<LCD_EN);						
	_delay_us(2000);								
}

void lcddata(unsigned char data)
{
	LCD_DPRT = (LCD_DPRT & 0x0f)|(data & 0xf0);		
	LCD_DPRT |= (1<<LCD_RS);						
	LCD_DPRT |= (1<<LCD_EN);						
	_delay_us(1);									
	LCD_DPRT &= ~(1<<LCD_EN);						
	_delay_us(100);									
	
	LCD_DPRT = (LCD_DPRT & 0x0f)|(data << 4);		
	LCD_DPRT |= (1<<LCD_EN);						
	_delay_us(1);									
	LCD_DPRT &= ~(1<<LCD_EN);						
	_delay_us(2000);								
}

void lcdinit()
{
	LCD_DDDR = 0xFF;
	_delay_ms(200);									
	lcdcommand(0x33);
	lcdcommand(0x32);								
	lcdcommand(0x28);								
	lcdcommand(0x0C);								
	lcdcommand(0x01);								
	lcdcommand(0x82);								
}
void lcd_print(char *str)
{
	unsigned char i=0;
	while (str[i] |= 0)
	{
		lcddata(str[i]);
		i++;
	}
}


void lcd_print_xy(char row, char pos, char* str)
{
	if (row == 0 && pos<16)
	lcdcommand((pos & 0x0F)|0x80);		
	else if (row == 1 && pos<16)
	lcdcommand((pos & 0x0F)|0xC0);		
	lcd_print(str);					
}

void lcd_clear()
{
	lcdcommand(0x01);
	_delay_ms(2);
}


#include <avr/io.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "I2C_Master_H_file.h"
#include "LCD16x2_4Bit.h"

#define Device_Write_address	0xD0				
#define Device_Read_address		0xD1				
#define TimeFormat12			0x40				
#define AMPM					0x20


int second,minute,hour,day,date,month,year;



bool IsItPM(char hour_)
{
	if(hour_ & (AMPM))
	return 1;
	else
	return 0;
}

void RTC_Read_Clock(char read_clock_address)
{
	I2C_Start(Device_Write_address);				
	I2C_Write(read_clock_address);					
	I2C_Repeated_Start(Device_Read_address);		

	second = I2C_Read_Ack();						
	minute = I2C_Read_Ack();						
	hour = I2C_Read_Nack();							
	I2C_Stop();										
}



int main(void)
{
	 char buffer[20];
	 // SET servo and dc motor as output
	 DDRD |=0B00000001;
	 DDRD |=0B00000010;
	 DDRD |=0B00000100;
	 DDRD |=0B00001000;
	 DDRD |=0B10000000;
	 
	I2C_Init();																		
    while(1)
    {
		RTC_Read_Clock(0);							
		 
		
		{
			sprintf(buffer, " %02x:%02x:%02x  ", (hour & 0b00011111), minute, second);
				
		}
	
		PORTD |=0B10000000;   
		
		}
		//dc motor 1  at walkin time on
		
		while((hour ==14) && (minute==11 )){
			  PORTD |=0B00000001;
			  _delay_ms(5000);
			    
		 }	
		
}

